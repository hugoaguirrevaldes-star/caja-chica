# Caja Chica — v3 (4 herramientas)

Este proyecto ya trae TODAS las variables de entorno que usaste en el proyecto anterior
(`punto-equilibrio-completo`) — no necesitas crear nada nuevo, solo asegurarte de copiarlas
a este proyecto nuevo en Vercel si lo subes como proyecto separado, o reemplazar el código
del proyecto existente y hacer Redeploy.

## Lo que cambió
- Diseño "Caja Chica" con tono envejecido/vintage
- 4 herramientas en vez de 2: Punto de Equilibrio, Precio Sugerido (gratis) + Registro de
  Ventas y Gastos con diagnóstico automático, Impuestos RESICO (premium)
- Campo nuevo: "¿cuánto quieres ganar extra este mes?" — ajusta la meta del diagnóstico
- Nueva colección en Firestore: `movimientos` (dentro de cada usuario)

## Un paso importante: volver a publicar las reglas de Firestore
Como se agregó la colección `movimientos`, tienes que:
1. Firebase Console → Firestore Database → pestaña "Reglas"
2. Reemplaza todo con el contenido del archivo `firestore.rules` de este proyecto
3. Dale "Publicar"

Sin este paso, el Registro no va a poder guardar nada (Firestore lo bloqueará por seguridad).

## Variables de entorno necesarias (las mismas de antes)
VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN, VITE_FIREBASE_PROJECT_ID,
VITE_FIREBASE_STORAGE_BUCKET, VITE_FIREBASE_MESSAGING_SENDER_ID, VITE_FIREBASE_APP_ID,
MERCADOPAGO_ACCESS_TOKEN, MERCADOPAGO_PUBLIC_KEY, PRECIO_PREMIUM_MXN, SITE_URL
