import { useState } from "react";
import { C } from "../tema.js";

export default function Premium({ user }) {
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState("");

  async function handleSuscribirse() {
    if (!user) return;
    setCargando(true);
    setError("");
    try {
      const res = await fetch("/api/create-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid: user.uid, email: user.email }),
      });
      const data = await res.json();
      if (data.init_point) {
        window.location.href = data.init_point;
      } else {
        setError("No se pudo iniciar la suscripción. Intenta de nuevo.");
      }
    } catch (e) {
      setError("Hubo un problema de conexión. Intenta de nuevo.");
    } finally {
      setCargando(false);
    }
  }

  const features = ["Registro de ventas y gastos con diagnóstico automático", "Calculadora de impuestos (RESICO)", "Historial guardado de todos tus cálculos"];

  return (
    <div style={{ background: C.bgCard, border: `1.5px solid ${C.mustard}`, padding: "22px 20px" }}>
      <p style={{ fontFamily: "Georgia, serif", fontSize: 18, margin: "0 0 4px", color: C.paper }}>🔒 HAZTE PREMIUM</p>
      <p style={{ color: C.tealFaint, fontSize: 12, margin: "0 0 16px" }}>$79 MXN / mes</p>
      {features.map((f) => (
        <div key={f} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 12, color: C.paper }}>
          <span style={{ color: C.mustard }}>✓</span>
          <span>{f}</span>
        </div>
      ))}
      {!user ? (
        <p style={{ fontSize: 11, color: C.tealFaint, marginTop: 12 }}>Inicia sesión arriba para suscribirte.</p>
      ) : (
        <button onClick={handleSuscribirse} disabled={cargando} style={{ width: "100%", marginTop: 14, padding: "12px", background: C.coral, color: C.paper, border: "none", fontWeight: 700, fontSize: 12, letterSpacing: "0.5px", cursor: "pointer" }}>
          {cargando ? "ABRIENDO MERCADO PAGO..." : "SUSCRIBIRME"}
        </button>
      )}
      {error && <p style={{ color: "#E08A7D", fontSize: 11, marginTop: 8 }}>{error}</p>}
    </div>
  );
}
