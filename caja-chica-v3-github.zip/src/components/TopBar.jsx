import { C, DISPLAY } from "../tema.js";
import { loginConGoogle, cerrarSesion } from "../firebase.js";

export default function TopBar({ user, premium }) {
  return (
    <div style={{ position: "sticky", top: 0, zIndex: 10, background: C.bg, borderBottom: `1px solid ${C.tealMuted}`, padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <CashBoxMark />
        <div>
          <div style={{ fontFamily: DISPLAY, fontSize: 17, letterSpacing: "0.5px", lineHeight: 1, fontWeight: 700 }}>Caja Chica</div>
          <div style={{ fontSize: 9, color: C.tealFaint, letterSpacing: "1.5px" }}>HERRAMIENTAS PARA TU NEGOCIO</div>
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        {user && (
          <span style={{ fontSize: 9, fontWeight: 700, color: premium ? C.mustard : C.tealFaint, border: `1px solid ${premium ? C.mustard : C.tealMuted}`, padding: "3px 7px" }}>
            {premium ? "PREMIUM" : "GRATIS"}
          </span>
        )}
        {user ? (
          <button onClick={() => cerrarSesion()} style={{ background: "transparent", color: C.paper, border: `1.5px solid ${C.tealMuted}`, fontWeight: 700, fontSize: 10, padding: "7px 12px", cursor: "pointer" }}>
            SALIR
          </button>
        ) : (
          <button onClick={() => loginConGoogle()} style={{ background: C.mustard, color: C.ink, border: `1.5px solid ${C.mustard}`, fontWeight: 700, fontSize: 10, padding: "7px 12px", cursor: "pointer" }}>
            ENTRAR
          </button>
        )}
      </div>
    </div>
  );
}

function CashBoxMark() {
  return (
    <svg width="26" height="26" viewBox="0 0 28 28" fill="none">
      <rect x="2" y="10" width="24" height="15" rx="1.5" fill={C.mustard} />
      <rect x="2" y="10" width="24" height="15" rx="1.5" stroke={C.ink} strokeWidth="1" />
      <rect x="6" y="14" width="16" height="2" fill={C.ink} opacity="0.5" />
      <path d="M4 10 L14 3 L24 10" stroke={C.mustard} strokeWidth="2" fill="none" strokeLinejoin="round" />
      <circle cx="14" cy="18" r="2" fill={C.coral} />
    </svg>
  );
}
