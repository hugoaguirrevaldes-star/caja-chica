import { C, MONO, DISPLAY } from "../tema.js";

export function TicketShell({ label, children }) {
  return (
    <div style={{ background: C.paper, boxShadow: "0 14px 34px rgba(0,0,0,0.5)" }}>
      <Perf top />
      <div style={{ padding: "20px 22px 26px" }}>
        <p style={{ color: "#5B4B30", fontSize: 11, letterSpacing: "2px", margin: "0 0 8px", fontWeight: 700, fontFamily: DISPLAY }}>{label}</p>
        <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "14px 0" }} />
        {children}
      </div>
      <Perf />
    </div>
  );
}
export function Perf({ top }) {
  const pos = top ? "0" : "10px";
  return <div style={{ height: 10, backgroundImage: `radial-gradient(circle at 10px ${pos}, ${C.bg} 6px, transparent 7px)`, backgroundSize: "20px 10px", backgroundRepeat: "repeat-x" }} />;
}
export function Field({ label, hint, value, onChange, prefix = "$" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 4 }}>
        <label style={{ color: C.ink, fontSize: 12, fontWeight: 700, letterSpacing: "0.5px" }}>{label}</label>
        <span style={{ color: "#7A6A48", fontSize: 10 }}>{hint}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", borderBottom: `2px solid ${C.ink}`, paddingBottom: 4 }}>
        <span style={{ color: C.ink, fontSize: 20, marginRight: 4, fontWeight: 700 }}>{prefix}</span>
        <input type="number" inputMode="decimal" value={value} onChange={(e) => onChange(e.target.value)} style={{ flex: 1, border: "none", background: "transparent", outline: "none", fontFamily: MONO, fontSize: 20, fontWeight: 700, color: C.ink }} />
      </div>
    </div>
  );
}
export function ResultRow({ label, value, big }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0" }}>
      <span style={{ color: C.tealMuted, fontSize: 12, fontWeight: 700, letterSpacing: "0.5px" }}>{label}</span>
      <span style={{ color: big ? C.coral : C.ink, fontSize: big ? 20 : 15, fontWeight: 700 }}>{value}</span>
    </div>
  );
}
