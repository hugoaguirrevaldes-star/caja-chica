import { useState, useEffect, useMemo } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { C, fmt } from "../tema.js";
import { TicketShell, Field, ResultRow } from "./Compartido.jsx";
import { guardarMovimiento, suscribirseAMovimientos, actualizarMetaExtra, obtenerPerfilUsuario } from "../firebase.js";

export default function Registro({ user, metaBase }) {
  const [movimientos, setMovimientos] = useState([]);
  const [gananciaExtra, setGananciaExtra] = useState("0");
  const [tipo, setTipo] = useState("venta");
  const [monto, setMonto] = useState("");
  const [nota, setNota] = useState("");

  useEffect(() => {
    if (!user) return;
    const unsub = suscribirseAMovimientos(user.uid, setMovimientos);
    obtenerPerfilUsuario(user.uid).then((p) => {
      if (p?.metaExtra) setGananciaExtra(String(p.metaExtra));
    });
    return () => unsub();
  }, [user]);

  const totalVentas = movimientos.filter((m) => m.tipo === "venta").reduce((s, m) => s + m.monto, 0);
  const totalGastos = movimientos.filter((m) => m.tipo === "gasto").reduce((s, m) => s + m.monto, 0);
  const balance = totalVentas - totalGastos;

  const extra = parseFloat(gananciaExtra) || 0;
  const metaIngresos = metaBase.unidades * metaBase.precioVenta + extra;
  const avance = metaIngresos > 0 ? Math.min(100, Math.round((totalVentas / metaIngresos) * 100)) : 0;
  const falta = Math.max(0, metaIngresos - totalVentas);

  const acumulado = useMemo(() => {
    let corte = 0;
    return [...movimientos].reverse().map((m, i) => {
      corte += m.tipo === "venta" ? m.monto : -m.monto;
      return { i, acumulado: corte };
    });
  }, [movimientos]);

  async function compartirNota(m) {
    const texto = `NOTA DE VENTA\n${m.nota}\nMonto: ${fmt(m.monto)}\nFecha: ${new Date(m.fecha).toLocaleDateString("es-MX")}\n\nGracias por tu compra.`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "Nota de venta", text: texto });
      } catch (e) {
        /* el usuario canceló, no pasa nada */
      }
    } else {
      await navigator.clipboard.writeText(texto);
      alert("Nota copiada — pégala en WhatsApp o donde quieras.");
    }
  }

  async function agregar() {
    const n = parseFloat(monto);
    if (!n || n <= 0 || !user) return;
    await guardarMovimiento(user.uid, tipo, n, nota || (tipo === "venta" ? "Venta" : "Gasto"));
    setMonto("");
    setNota("");
  }

  async function handleGananciaExtra(v) {
    setGananciaExtra(v);
    if (user) await actualizarMetaExtra(user.uid, parseFloat(v) || 0);
  }

  return (
    <>
      <div style={{ background: C.bgCard, padding: "14px 16px", marginBottom: 14, border: `1px solid ${C.tealMuted}` }}>
        <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.5px", color: C.paper }}>¿CUÁNTO QUIERES GANAR EXTRA ESTE MES?</label>
        <div style={{ fontSize: 9, color: C.tealFaint, margin: "4px 0 6px" }}>además de cubrir tus costos — 0 si solo quieres tu punto de equilibrio</div>
        <div style={{ display: "flex", alignItems: "center", borderBottom: `2px solid ${C.paper}`, paddingBottom: 4 }}>
          <span style={{ fontSize: 18, marginRight: 4, fontWeight: 700, color: C.paper }}>$</span>
          <input type="number" inputMode="decimal" value={gananciaExtra} onChange={(e) => handleGananciaExtra(e.target.value)} style={{ flex: 1, border: "none", background: "transparent", outline: "none", fontSize: 18, fontWeight: 700, color: C.paper }} />
        </div>
      </div>

      {metaIngresos > 0 && (
        <div style={{ background: C.bgCard, padding: "16px 16px", marginBottom: 14, border: `1px solid ${C.mustard}` }}>
          <p style={{ fontSize: 10, letterSpacing: "1.5px", color: C.mustard, fontWeight: 700, margin: "0 0 8px" }}>DIAGNÓSTICO AUTOMÁTICO</p>
          <p style={{ fontSize: 13, lineHeight: 1.6, margin: "0 0 10px", color: C.paper }}>
            Vas al <strong style={{ color: C.mustard }}>{avance}%</strong> de tu meta del mes ({fmt(metaIngresos)}).{" "}
            {falta > 0 ? <>Te faltan <strong>{fmt(falta)}</strong> para llegar.</> : <>¡Ya llegaste a tu meta! 🎉</>}
          </p>
          <div style={{ background: "#4A3D2C", height: 10, borderRadius: 6, overflow: "hidden" }}>
            <div style={{ width: `${avance}%`, height: "100%", background: avance >= 100 ? C.green : C.mustard }} />
          </div>
        </div>
      )}

      <TicketShell label="REGISTRO">
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          {["venta", "gasto"].map((t) => (
            <div key={t} onClick={() => setTipo(t)} style={{ flex: 1, textAlign: "center", padding: "8px", fontSize: 11, fontWeight: 700, cursor: "pointer", border: `1.5px solid ${t === "venta" ? C.mustard : C.coral}`, background: tipo === t ? (t === "venta" ? C.mustard : C.coral) : "transparent", color: tipo === t ? C.paper : C.ink }}>
              {t === "venta" ? "VENDÍ" : "GASTÉ"}
            </div>
          ))}
        </div>
        <Field label="MONTO" hint="" value={monto} onChange={setMonto} />
        <div style={{ marginBottom: 12 }}>
          <input placeholder="Nota (ej. tortillas, cliente frecuente...)" value={nota} onChange={(e) => setNota(e.target.value)} style={{ width: "100%", border: `1px solid ${C.border}`, background: "transparent", padding: 8, fontSize: 12, color: C.ink, boxSizing: "border-box" }} />
        </div>
        <button onClick={agregar} style={{ width: "100%", padding: 12, background: C.ink, color: C.paper, border: "none", fontWeight: 700, fontSize: 12, letterSpacing: "0.5px", cursor: "pointer" }}>
          AGREGAR AL REGISTRO
        </button>
        <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "16px 0" }} />
        <ResultRow label="VENTAS ACUMULADAS" value={fmt(totalVentas)} />
        <ResultRow label="GASTOS ACUMULADOS" value={fmt(totalGastos)} />
        <ResultRow label="TE QUEDA" value={fmt(balance)} big />
        <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "16px 0" }} />
        <p style={{ color: "#5B4B30", fontSize: 11, letterSpacing: "1px", fontWeight: 700, marginBottom: 8 }}>MOVIMIENTOS</p>
        {movimientos.length === 0 && <p style={{ color: C.tealMuted, fontSize: 12 }}>Aún no registras nada.</p>}
        {movimientos.map((m) => (
          <div key={m.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12, padding: "5px 0", borderBottom: "1px dotted #C9B98E" }}>
            <span style={{ color: C.ink }}>{m.nota}</span>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: m.tipo === "venta" ? "#4A6B3E" : C.coral, fontWeight: 700 }}>{m.tipo === "venta" ? "+" : "−"}{fmt(m.monto)}</span>
              {m.tipo === "venta" && (
                <button
                  onClick={() => compartirNota(m)}
                  title="Compartir nota de venta"
                  style={{ background: "none", border: `1px solid ${C.border}`, borderRadius: 4, padding: "2px 6px", fontSize: 10, cursor: "pointer", color: C.ink }}
                >
                  🧾
                </button>
              )}
            </div>
          </div>
        ))}
      </TicketShell>

      {acumulado.length > 1 && (
        <div style={{ background: C.bgCard, marginTop: 14, padding: "16px 12px" }}>
          <p style={{ fontSize: 10, letterSpacing: "2px", fontWeight: 700, margin: "0 0 8px 6px", color: C.paper }}>CÓMO SE HA IDO ACUMULANDO</p>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={acumulado} margin={{ top: 6, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid stroke={C.tealMuted} strokeDasharray="3 3" />
              <XAxis dataKey="i" stroke={C.paper} tick={{ fill: C.tealFaint, fontSize: 9 }} />
              <YAxis stroke={C.paper} tick={{ fill: C.tealFaint, fontSize: 9 }} width={44} />
              <Area type="monotone" dataKey="acumulado" stroke={C.mustard} fill={C.mustard} fillOpacity={0.25} strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </>
  );
}
