import { useEffect, useState } from "react";
import { C, fmt } from "../tema.js";
import { TicketShell } from "./Compartido.jsx";
import { suscribirseAHistorial } from "../firebase.js";

export default function Historial({ user }) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (!user) return;
    const unsub = suscribirseAHistorial(user.uid, setItems);
    return () => unsub();
  }, [user]);

  if (items.length === 0) {
    return <p style={{ color: C.tealFaint, fontSize: 12, textAlign: "center", marginTop: 12 }}>Aún no has guardado ningún cálculo.</p>;
  }

  return (
    <TicketShell label="HISTORIAL GUARDADO">
      {items.map((it) => (
        <div key={it.id} style={{ marginBottom: 14 }}>
          <p style={{ color: C.ink, fontSize: 11, fontWeight: 700, marginBottom: 4 }}>
            {it.tipo?.toUpperCase()} — {new Date(it.fecha).toLocaleDateString("es-MX")}
          </p>
          <p style={{ color: C.tealMuted, fontSize: 12, margin: 0 }}>{JSON.stringify(it.datos)}</p>
        </div>
      ))}
    </TicketShell>
  );
}
