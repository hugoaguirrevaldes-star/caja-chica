import { useState, useMemo, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ReferenceDot, ResponsiveContainer } from "recharts";
import { C, fmt } from "../tema.js";
import { TicketShell, Field, ResultRow } from "./Compartido.jsx";

export default function PuntoEquilibrio({ onCalculado }) {
  const [cf, setCf] = useState("8000");
  const [cv, setCv] = useState("35");
  const [pv, setPv] = useState("60");
  const nCf = parseFloat(cf) || 0, nCv = parseFloat(cv) || 0, nPv = parseFloat(pv) || 0;
  const margen = nPv - nCv;
  const { unidades, valido } = useMemo(() => {
    if (margen <= 0) return { unidades: 0, valido: false };
    return { unidades: Math.ceil(nCf / margen), valido: true };
  }, [nCf, margen]);

  useEffect(() => {
    if (valido) onCalculado?.({ unidades, precioVenta: nPv });
  }, [valido, unidades, nPv]);

  const data = useMemo(() => {
    if (!valido) return [];
    const max = Math.ceil(unidades * 2) || 10;
    const step = Math.max(1, Math.round(max / 8));
    const pts = [];
    for (let u = 0; u <= max; u += step) pts.push({ u, ingresos: u * nPv, costos: nCf + u * nCv });
    return pts;
  }, [unidades, valido, nPv, nCv, nCf]);

  return (
    <>
      <TicketShell label="TICKET · PUNTO DE EQUILIBRIO">
        <Field label="COSTOS FIJOS AL MES" hint="renta, luz, sueldos..." value={cf} onChange={setCf} />
        <Field label="COSTO POR UNIDAD" hint="lo que te cuesta producirla" value={cv} onChange={setCv} />
        <Field label="PRECIO DE VENTA" hint="lo que le cobras al cliente" value={pv} onChange={setPv} />
        <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "14px 0" }} />
        {!valido ? (
          <div style={{ background: "#E8C9B0", border: `1.5px dashed ${C.coral}`, color: "#6B2A1F", fontSize: 12, lineHeight: 1.5, padding: 12 }}>
            El precio de venta debe ser mayor al costo por unidad.
          </div>
        ) : (
          <>
            <ResultRow label="GANAS POR UNIDAD" value={fmt(margen)} />
            <ResultRow label="NECESITAS VENDER" value={`${unidades} unidades/mes`} big />
            <ResultRow label="PARA CUBRIR" value={fmt(nCf)} />
          </>
        )}
      </TicketShell>
      {valido && (
        <div style={{ background: C.bgCard, marginTop: 14, padding: "16px 12px" }}>
          <p style={{ fontSize: 10, letterSpacing: "2px", fontWeight: 700, margin: "0 0 8px 6px", color: C.paper }}>INGRESOS VS. COSTOS</p>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid stroke={C.tealMuted} strokeDasharray="3 3" />
              <XAxis dataKey="u" stroke={C.paper} tick={{ fill: C.tealFaint, fontSize: 10 }} />
              <YAxis stroke={C.paper} tick={{ fill: C.tealFaint, fontSize: 10 }} width={46} />
              <Line type="monotone" dataKey="costos" stroke={C.coral} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="ingresos" stroke={C.mustard} strokeWidth={2} dot={false} />
              <ReferenceDot x={unidades} y={unidades * nPv} r={5} fill={C.paper} stroke={C.bg} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </>
  );
}
