import { useState, useMemo } from "react";
import { C, fmt } from "../tema.js";
import { TicketShell, Field, ResultRow } from "./Compartido.jsx";

const TABLA_RESICO = [
  { hasta: 25000, tasa: 0.01 },
  { hasta: 50000, tasa: 0.011 },
  { hasta: 83333.33, tasa: 0.015 },
  { hasta: 208333.33, tasa: 0.02 },
  { hasta: Infinity, tasa: 0.025 },
];

export default function Impuestos() {
  const [ingresos, setIngresos] = useState("15000");
  const n = parseFloat(ingresos) || 0;

  const { tasa, isr } = useMemo(() => {
    const tramo = TABLA_RESICO.find((t) => n <= t.hasta) || TABLA_RESICO[TABLA_RESICO.length - 1];
    return { tasa: tramo.tasa, isr: n * tramo.tasa };
  }, [n]);

  return (
    <TicketShell label="TICKET · IMPUESTO ESTIMADO (RESICO)">
      <Field label="INGRESOS COBRADOS ESTE MES" hint="lo que de verdad te pagaron" value={ingresos} onChange={setIngresos} />
      <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "14px 0" }} />
      <ResultRow label="TASA APLICABLE" value={`${(tasa * 100).toFixed(2)}%`} />
      <ResultRow label="ISR ESTIMADO A PAGAR" value={fmt(isr)} big />
      <ResultRow label="TE QUEDA NETO" value={fmt(n - isr)} />
      <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "16px 0" }} />
      <p style={{ color: C.tealMuted, fontSize: 11, lineHeight: 1.6, margin: 0 }}>
        Estimado con la tabla RESICO para personas físicas 2026 (1% a 2.5% según tus ingresos del mes). Es una referencia rápida, no sustituye a tu contador ni tu declaración oficial ante el SAT.
      </p>
    </TicketShell>
  );
}
