import { useState, useMemo } from "react";
import { C, fmt } from "../tema.js";
import { TicketShell, Field, ResultRow } from "./Compartido.jsx";

export default function PrecioSugerido() {
  const [costo, setCosto] = useState("35");
  const [margen, setMargen] = useState("40");
  const c = parseFloat(costo) || 0, m = parseFloat(margen) || 0;
  const { precio, valido } = useMemo(() => {
    if (m <= 0 || m >= 100 || c <= 0) return { precio: 0, valido: false };
    return { precio: c / (1 - m / 100), valido: true };
  }, [c, m]);
  return (
    <TicketShell label="TICKET · PRECIO SUGERIDO">
      <Field label="COSTO POR UNIDAD" hint="lo que te cuesta producirla" value={costo} onChange={setCosto} />
      <Field label="MARGEN QUE QUIERES" hint="ej. 40 = 40%" value={margen} onChange={setMargen} prefix="%" />
      <div style={{ borderTop: `1.5px dashed ${C.border}`, margin: "14px 0" }} />
      {!valido ? (
        <div style={{ background: "#E8C9B0", border: `1.5px dashed ${C.coral}`, color: "#6B2A1F", fontSize: 12, lineHeight: 1.5, padding: 12 }}>
          Revisa los datos: costo mayor a cero, margen entre 1% y 99%.
        </div>
      ) : (
        <>
          <ResultRow label="DEBES COBRAR" value={fmt(precio)} big />
          <ResultRow label="GANANCIA POR UNIDAD" value={fmt(precio - c)} />
        </>
      )}
    </TicketShell>
  );
}
