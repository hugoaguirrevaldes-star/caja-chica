export const C = {
  bg: "#241C14",
  bgCard: "#332821",
  paper: "#EDE0C8",
  ink: "#2E2013",
  mustard: "#C68A2E",
  coral: "#A8402F",
  green: "#6B9B5E",
  tealMuted: "#6B5B3E",
  tealFaint: "#B8A87E",
  border: "#8C7A54",
};
export const MONO = "'Courier New', Courier, monospace";
export const DISPLAY = "'Georgia', 'Times New Roman', serif";
export const fmt = (n) => n.toLocaleString("es-MX", { style: "currency", currency: "MXN", maximumFractionDigits: 0 });
