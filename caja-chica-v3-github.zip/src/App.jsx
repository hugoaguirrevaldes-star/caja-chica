import { useEffect, useState } from "react";
import { suscribirseAUsuario, obtenerPerfilUsuario, crearPerfilUsuarioSiNoExiste, loginConGoogle } from "./firebase.js";
import { C, MONO, DISPLAY } from "./tema.js";
import TopBar from "./components/TopBar.jsx";
import PuntoEquilibrio from "./components/PuntoEquilibrio.jsx";
import PrecioSugerido from "./components/PrecioSugerido.jsx";
import Registro from "./components/Registro.jsx";
import Impuestos from "./components/Impuestos.jsx";
import Historial from "./components/Historial.jsx";
import Premium from "./components/Premium.jsx";

const TABS = [
  { id: "equilibrio", label: "EQUILIBRIO", libre: true },
  { id: "precio", label: "PRECIO", libre: true },
  { id: "registro", label: "REGISTRO", libre: false },
  { id: "impuestos", label: "IMPUESTOS", libre: false },
  { id: "historial", label: "HISTORIAL", libre: false },
];

export default function App() {
  const [user, setUser] = useState(null);
  const [premium, setPremium] = useState(false);
  const [tab, setTab] = useState("equilibrio");
  const [cargando, setCargando] = useState(true);
  const [meta, setMeta] = useState({ unidades: 320, precioVenta: 60 });

  useEffect(() => {
    const unsub = suscribirseAUsuario(async (u) => {
      setUser(u);
      if (u) {
        await crearPerfilUsuarioSiNoExiste(u);
        const perfil = await obtenerPerfilUsuario(u.uid);
        setPremium(!!perfil?.premium);
      } else {
        setPremium(false);
      }
      setCargando(false);
    });
    return () => unsub();
  }, []);

  const tabActual = TABS.find((t) => t.id === tab);
  const puedeVer = tabActual.libre || premium;

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: MONO, color: C.paper }}>
      <TopBar user={user} premium={premium} />

      {!user && !cargando && <Hero />}

      <div style={{ maxWidth: 420, margin: "0 auto", padding: "20px 16px 60px" }}>
        <div style={{ display: "flex", marginBottom: 16, background: C.bgCard, padding: 3, flexWrap: "wrap", gap: 2 }}>
          {TABS.map((t) => (
            <div
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                flex: "1 0 30%",
                textAlign: "center",
                padding: "8px 2px",
                fontSize: 8.5,
                fontWeight: 700,
                letterSpacing: "0.3px",
                cursor: "pointer",
                color: tab === t.id ? C.ink : C.tealFaint,
                background: tab === t.id ? C.mustard : "transparent",
              }}
            >
              {!t.libre && "🔒 "}
              {t.label}
            </div>
          ))}
        </div>

        {!cargando && (
          <>
            {tab === "equilibrio" && <PuntoEquilibrio onCalculado={setMeta} />}
            {tab === "precio" && <PrecioSugerido />}

            {tab === "registro" && (puedeVer ? <Registro user={user} metaBase={meta} /> : <VistaBloqueada user={user}><VistaPreviaRegistro /></VistaBloqueada>)}
            {tab === "impuestos" && (puedeVer ? <Impuestos /> : <VistaBloqueada user={user}><VistaPreviaImpuestos /></VistaBloqueada>)}
            {tab === "historial" && (puedeVer ? <Historial user={user} /> : <VistaBloqueada user={user}><VistaPreviaHistorial /></VistaBloqueada>)}
          </>
        )}
      </div>
    </div>
  );
}

// ---------- Bienvenida (solo si no ha iniciado sesión) ----------
function Hero() {
  return (
    <div style={{ padding: "0 16px 24px", borderBottom: `1px solid ${C.tealMuted}` }}>
      <div style={{ maxWidth: 420, margin: "0 auto", textAlign: "center", paddingTop: 24 }}>
        <p style={{ color: C.mustard, fontSize: 11, letterSpacing: "3px", margin: 0 }}>PARA CHANGARROS Y NEGOCIOS CHICOS</p>
        <h1 style={{ fontFamily: DISPLAY, fontSize: 26, lineHeight: 1.2, margin: "10px 0" }}>Sabe cuánto vender, cuánto cobrar, y cuánto te queda</h1>

        <div style={{ display: "inline-block", background: C.mustard, color: C.ink, fontWeight: 700, fontSize: 13, padding: "8px 16px", margin: "6px 0 18px" }}>
          7 DÍAS GRATIS DE PRUEBA — SIN COMPROMISO
        </div>

        <div style={{ background: C.bgCard, padding: "16px", textAlign: "left", marginBottom: 16 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
            <thead>
              <tr>
                <td></td>
                <td style={{ textAlign: "center", fontWeight: 700, color: C.tealFaint, padding: 6 }}>GRATIS</td>
                <td style={{ textAlign: "center", fontWeight: 700, color: C.mustard, padding: 6 }}>PREMIUM</td>
              </tr>
            </thead>
            <tbody>
              {[
                ["Punto de equilibrio", true, true],
                ["Precio sugerido", true, true],
                ["Registro + diagnóstico", false, true],
                ["Calculadora de impuestos", false, true],
                ["Historial guardado", false, true],
              ].map(([label, g, p]) => (
                <tr key={label} style={{ borderTop: `1px solid ${C.tealMuted}` }}>
                  <td style={{ padding: "8px 4px" }}>{label}</td>
                  <td style={{ textAlign: "center" }}>{g ? "✓" : "—"}</td>
                  <td style={{ textAlign: "center", color: C.mustard }}>{p ? "✓" : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button onClick={() => loginConGoogle()} style={{ background: C.coral, color: C.paper, border: "none", fontWeight: 700, fontSize: 13, padding: "13px 28px", cursor: "pointer", marginBottom: 10 }}>
          ENTRAR CON GOOGLE
        </button>
        <p style={{ color: C.tealFaint, fontSize: 10, letterSpacing: "0.5px" }}>🔒 Pago seguro procesado por Mercado Pago</p>
      </div>
    </div>
  );
}

// ---------- Vista bloqueada: muestra la herramienta borrosa + botón de suscripción encima ----------
function VistaBloqueada({ user, children }) {
  return (
    <div style={{ position: "relative" }}>
      <div style={{ filter: "blur(3px)", opacity: 0.5, pointerEvents: "none", userSelect: "none" }}>{children}</div>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: 12 }}>
        <div style={{ width: "100%", maxWidth: 320 }}>
          <Premium user={user} />
        </div>
      </div>
    </div>
  );
}

// Vistas previas estáticas (solo para mostrar detrás del candado, sin datos reales)
function VistaPreviaRegistro() {
  return (
    <div style={{ background: C.paper, color: C.ink, padding: 20, boxShadow: "0 14px 34px rgba(0,0,0,0.5)" }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: C.mustard, marginBottom: 8 }}>DIAGNÓSTICO AUTOMÁTICO</p>
      <p style={{ fontSize: 13, marginBottom: 10 }}>Vas al 65% de tu meta del mes ($19,200). Te faltan $6,800 para llegar.</p>
      <div style={{ background: "#ddd", height: 10, borderRadius: 6, marginBottom: 16 }}>
        <div style={{ width: "65%", height: "100%", background: C.mustard }} />
      </div>
      <p style={{ fontSize: 11, fontWeight: 700 }}>VENTAS ACUMULADAS · $12,400</p>
      <p style={{ fontSize: 11, fontWeight: 700 }}>GASTOS ACUMULADOS · $1,800</p>
    </div>
  );
}
function VistaPreviaImpuestos() {
  return (
    <div style={{ background: C.paper, color: C.ink, padding: 20, boxShadow: "0 14px 34px rgba(0,0,0,0.5)" }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: "#5B4B30", marginBottom: 8 }}>TICKET · IMPUESTO ESTIMADO</p>
      <p style={{ fontSize: 13 }}>Tasa aplicable: 1.50%</p>
      <p style={{ fontSize: 20, fontWeight: 700, color: C.coral }}>ISR estimado: $225</p>
    </div>
  );
}
function VistaPreviaHistorial() {
  return (
    <div style={{ background: C.paper, color: C.ink, padding: 20, boxShadow: "0 14px 34px rgba(0,0,0,0.5)" }}>
      <p style={{ fontSize: 11, fontWeight: 700, color: "#5B4B30", marginBottom: 8 }}>HISTORIAL GUARDADO</p>
      <p style={{ fontSize: 12 }}>Punto de equilibrio — 12 jul: 320 unidades/mes</p>
      <p style={{ fontSize: 12 }}>Precio sugerido — 15 jul: cobra $58</p>
    </div>
  );
}
