import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, doc, getDoc, setDoc, collection, addDoc, query, orderBy, onSnapshot } from "firebase/firestore";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

const provider = new GoogleAuthProvider();

export function loginConGoogle() {
  return signInWithPopup(auth, provider);
}
export function cerrarSesion() {
  return signOut(auth);
}
export function suscribirseAUsuario(callback) {
  return onAuthStateChanged(auth, callback);
}

// --- Perfil del usuario ---
export async function obtenerPerfilUsuario(uid) {
  const ref = doc(db, "usuarios", uid);
  const snap = await getDoc(ref);
  return snap.exists() ? snap.data() : null;
}

export async function crearPerfilUsuarioSiNoExiste(user) {
  const ref = doc(db, "usuarios", user.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      nombre: user.displayName || "",
      email: user.email || "",
      premium: false,
      metaExtra: 0,
      creadoEn: new Date().toISOString(),
    });
  }
}

export async function actualizarMetaExtra(uid, metaExtra) {
  const ref = doc(db, "usuarios", uid);
  await setDoc(ref, { metaExtra }, { merge: true });
}

// --- Historial de cálculos guardados (premium) ---
export async function guardarCalculo(uid, tipo, datos) {
  const ref = collection(db, "usuarios", uid, "calculos");
  await addDoc(ref, { tipo, datos, fecha: new Date().toISOString() });
}
export function suscribirseAHistorial(uid, callback) {
  const ref = collection(db, "usuarios", uid, "calculos");
  const q = query(ref, orderBy("fecha", "desc"));
  return onSnapshot(q, (snap) => callback(snap.docs.map((d) => ({ id: d.id, ...d.data() }))));
}

// --- Registro de ventas y gastos (premium) ---
export async function guardarMovimiento(uid, tipo, monto, nota) {
  const ref = collection(db, "usuarios", uid, "movimientos");
  await addDoc(ref, { tipo, monto, nota, fecha: new Date().toISOString() });
}
export function suscribirseAMovimientos(uid, callback) {
  const ref = collection(db, "usuarios", uid, "movimientos");
  const q = query(ref, orderBy("fecha", "desc"));
  return onSnapshot(q, (snap) => callback(snap.docs.map((d) => ({ id: d.id, ...d.data() }))));
}
