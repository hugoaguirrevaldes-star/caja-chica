// Vercel Serverless Function
// Mercado Pago llama a esta URL cuando algo pasa con una suscripción (pago, cancelación, etc.)
// Nosotros verificamos el estado y actualizamos "premium: true/false" en Firestore.

import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

function getAdminDb() {
  if (getApps().length === 0) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
    initializeApp({ credential: cert(serviceAccount) });
  }
  return getFirestore();
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(200).send("ok"); // Mercado Pago a veces prueba con GET
  }

  const { type, data } = req.body || {};

  if (type !== "preapproval" || !data?.id) {
    return res.status(200).json({ recibido: true });
  }

  const ACCESS_TOKEN = process.env.MERCADOPAGO_ACCESS_TOKEN;

  try {
    const mpRes = await fetch(`https://api.mercadopago.com/preapproval/${data.id}`, {
      headers: { Authorization: `Bearer ${ACCESS_TOKEN}` },
    });
    const preapproval = await mpRes.json();

    const uid = preapproval.external_reference;
    const esPremium = preapproval.status === "authorized";

    if (uid) {
      const db = getAdminDb();
      await db.collection("usuarios").doc(uid).set(
        { premium: esPremium, mercadopagoPreapprovalId: data.id },
        { merge: true }
      );
    }

    return res.status(200).json({ recibido: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Error de servidor" });
  }
}
