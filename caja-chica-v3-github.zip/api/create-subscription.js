// Vercel Serverless Function
// Crea una suscripción (preapproval) en Mercado Pago y devuelve el link de pago.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método no permitido" });
  }

  const { uid, email } = req.body || {};
  if (!uid || !email) {
    return res.status(400).json({ error: "Falta uid o email" });
  }

  const ACCESS_TOKEN = process.env.MERCADOPAGO_ACCESS_TOKEN;
  const PRECIO_MENSUAL = Number(process.env.PRECIO_PREMIUM_MXN || 79); // cámbialo con una variable de entorno
  const SITE_URL = process.env.SITE_URL || `https://${req.headers.host}`;

  try {
    const mpRes = await fetch("https://api.mercadopago.com/preapproval", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ACCESS_TOKEN}`,
      },
      body: JSON.stringify({
        reason: "Punto de Equilibrio — Plan Premium",
        external_reference: uid,
        payer_email: email,
        back_url: `${SITE_URL}?suscripcion=exitosa`,
        auto_recurring: {
          frequency: 1,
          frequency_type: "months",
          transaction_amount: PRECIO_MENSUAL,
          currency_id: "MXN",
          free_trial: {
            frequency: 7,
            frequency_type: "days",
          },
        },
        status: "pending",
      }),
    });

    const data = await mpRes.json();

    if (!mpRes.ok) {
      console.error("Error de Mercado Pago:", data);
      return res.status(500).json({ error: "Mercado Pago rechazó la solicitud", detalle: data });
    }

    return res.status(200).json({ init_point: data.init_point });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Error de servidor" });
  }
}
